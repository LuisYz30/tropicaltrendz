# Tropical Trendz

Proyecto Laravel + Bootstrap para venta de trajes de baño en Colombia.